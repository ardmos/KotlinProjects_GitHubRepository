package com.ardmos.login_with_firebase

data class Memo(var message: String, var timestamp: Long)
